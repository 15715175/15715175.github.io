---
authors:
- Tianchen Liu
bio: My research interests include machine learning.
education:
  courses:
  - course: MSc in Biostatistics & Data Science
    institution: Weill Cornell Medicine
    year: 2019
  - course: BSc in Risk and Actuarial Studies
    institution: University College Cork,Ireland
    year: 2017
  - course: BSc in Statistics
    institution: Beijing Technology and Business University
    year: 2015
email: ""
interests:
- Machine Learning
- Logistical Regression
- Time Series Model
- Survival Model

name: Tianchen Liu
organizations:
- name: Weill Cornell Medicine
  url: ""
role: Student
social:
- icon: envelope
  icon_pack: fas
  link: '#contact'
- icon: fa-envelope fa-lg
  link: mailto:<ltc15861996149@163.com>
- icon: twitter
  icon_pack: fab
  link: https://twitter.com/tianchen_Liu
- icon: github
  icon_pack: fab
  link: http://github.com/15715175
- icon: fa-linkedin fa-lg
  link: https://www.linkedin.com/in/tianchen-liu-0b3118148/
superuser: true
user_groups:
- Researchers
- Visitors
---

Tianchen Liu is a student of Biostatistics & Data Science at Weill Cornell Medicine. Her research interests include Machine Learning, Logistical Regression, Time Series Model and Survival Model.
