+++
# Experience widget.
widget = "experience"  # See https://sourcethemes.com/academic/docs/page-builder/
headless = true  # This file represents a page section.
active = true  # Activate this widget? true/false
weight = 40  # Order that this section will appear.

title = "Experience"
subtitle = ""

# Date format for experience
#   Refer to https://sourcethemes.com/academic/docs/customization/#date-format
date_format = "Jan 2006"

# Experiences.
#   Add/remove as many `[[experience]]` blocks below as you like.
#   Required fields are `title`, `company`, and `date_start`.
#   Leave `date_end` empty if it's your current employer.
#   Begin/end multi-line descriptions with 3 quotes `"""`.
[[experience]]
  title = "Internship"
  company = "Morgan Stanley Capital International (MSCI)"
  company_url = ""
  location = "Remote PTA Internship"
  date_start = "2018-07-01"
  date_end = "2018-09-01"
  description = """
  
  Responsibilities include:
  
  * Used MATLAB to calculate 10 days 99% Monte Carlo Simulation based Value at Risk for specific portfolios
  * Adopted Newton-Raphson method to solve non-linear equation, utilized Monte Carlo methodology to price an
American option
  * Utilized Bootstrap to calculate the specific interest rate in given time periods and to find the present value of
different interest rate swap position
* Adopted Matlab to calculate SharpeRatio, to implement the Long/Short Equity strategy and to extend the
results until someday in the future
  """
  
[[experience]]
  title = "Researcher"
  company = "Chinese Academy of Sciences"
  company_url = ""
  location = "Beijing, China"
  date_start = "2018-08-01"
  date_end = "2018-09-01"
  description = """
  
  Research on Securities Investment Decision and Quantitative Modeling
  
  Responsibilities include:
  
  * Chose five stocks in different areas as a portfolio, analyzed each stock, used Markowitz Mean-Variance Model to find out the best asset allocation strategy and make the best investment decisions
  * Utilized Markowitz Mean-Variance Model, Black-Litterman Model and Risk Parity Model to allocate Fund of Fund asset
  * Optimized Risk Parity Model from three aspects, including using LTT Model for weight adjustment, adding different other risk factors into the portfolio, establishing Multiple Index Model based on fundamental analysis
  *Employed the established strategy to make a proposal for the investment of fund of fund in China
  """
  
  [[experience]]
  title = "Analyst"
  company = "Mathematical Contest in Modeling"
  company_url = ""
  location = "United States"
  date_start = "2018-02-01"
  date_end = "2018-02-05"
  description = """
  
  Analysis and Optimization to the Charging Network System
  
  Responsibilities include:
  
  * Built Aggregate Charging Network Prediction Model, which includes two sub-models to analyze the distribu-
tion of charging network in Ireland and America
  * Created a Multi-stage Charging Network Optimization Model to find an optimal solution to keep the transition
time from gas vehicle to electric one minimum with cost as little as possible
  * Utilized Sentitive Analysis to find out that the distribution of population and government investment is the key
factor in each model
  """
  
  [[experience]]
  title = "Analyst"
  company = "Mathematical Contest in Modeling"
  company_url = ""
  location = "United States"
  date_start = "2017-01-23"
  date_end = "2017-01-27"
  description = """
  
  Managing the Zambezi River
  
  Responsibilities include:
  
  * Utilized the Integrative Dam Assessment Modeling (IDAM) to comprehensively evaluate the potential costs
and benefits of each option based on biophysical, socio-economic and geopolitical impacts
  * Calculated the optimal number and placement of smaller dams by Harmony Search Algorithm (HSA) with
MATLAB and estimated the water flow near the Kariba Dam according to Numerical Simulation
  * Drew the conclusion that our system can properly handle flooding and low water conditions by applying Ma-
trix Structure Optimization and multi-criteria planning techniques
  """
+++


