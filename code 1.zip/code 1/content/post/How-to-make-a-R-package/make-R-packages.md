---
date: "2019-10-30"
diagram: true
image:
  caption: 'Image credit: [**John Moeses Bauan**](https://unsplash.com/photos/OGZtQF8iC0g)'
  placement: 3
markup: mmark
math: true
title: How to make a R package
---

You can focus on the content to learn to make a R package.

R packages are collections of functions and data sets developed by the community. They increase the power of R by improving existing base R functionalities, or by adding new ones.

Hadley Wickham said that "R Packages are the fundamental units of reproducible R code. They include eusable R functions, the documentation that describes how to use them, sample data.""

You can make an R package to share code with other people or as aresource just for yourself with functions that you frequently use.

To create a new package in RStudio go to File >> New Project.Select to make a new project in a new directory. 
 
Next, select the project type as an R Package.

Then, Name the R Package, select the working directory that the Rpackage will live in, and click ‘Create Package’.

Finally, go to the directory and checkout what you have and you can see the same thing inside of RStudio. Congratulations!